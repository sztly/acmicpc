//LCA_ST
struct Edge{
	int v,next,d;
}edge[N];

int n,m,cnt,head[N];
int r[N],dep[N],anc[N][H],dis[N],maxh;

void AddEdge(int u,int v,int c)
{
	edge[cnt].v = v;
	edge[cnt].next = head[u];
	edge[cnt].d = c;
	head[u] = cnt++; 
}

void dfs(int root)
{
	for(int i=head[root]; i!=-1; i=edge[i].next){
		int v = edge[i].v;
		dis[v] = dis[root]+edge[i].d;
		dep[v] = dep[root]+1;
		anc[v][0] = root;
		for(int j=1; j<=maxh; j++){
			int t = anc[v][j-1];
			anc[v][j] = anc[t][j-1];
		}
		dfs(v);
	}
}

void swim(int& x,int h)
{
	for(int i=0; h>0; i++){
		if(h & 1) x = anc[x][i];
		h >>= 1;
	}
}

int LCA(int x,int y)
{
	int i;
	if(dep[x] > dep[y]) swap(x,y);
	swim(y,dep[y]-dep[x]);
	if(x == y) return x;
	while(1){
		for(int i=0; anc[x][i]!=anc[y][i]; i++);
		if(i == 0) return anc[x][0];
		x = anc[x][i-1];
		y = anc[y][i-1];
	}
	return -1;
}