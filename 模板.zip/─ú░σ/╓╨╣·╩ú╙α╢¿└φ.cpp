//中国剩余定理，返回在M中的唯一解 
struct CRT{
	int a[maxn],m[maxn],n;
	CRT(){}
	void read(){
		scanf("%d",&n);
		for(int i=0; i<n; i++){
			scanf("%d %d",&a[i],&m[i]);
		}
	}
	int solve(){
		long long M = 1,Mi;
		int x,y,d,ans = 0;
		for(int i=0; i<n; i++) M *= m[i];
		for(int i=0; i<n; i++){
			Mi = M/m[i];
			d = extend_gcd(Mi,m[i],x,y);
			ans = (ans+Mi*x*a[i])%M;
		}
		if(ans < 0) ans += M;
		return ans;
	}
}; 