//欧拉函数+素数筛选 
int euler[pn+2];
void Get_Euler(int n=pn){
	memset(euler,0,sizeof(euler));
	euler[1] = 1;
	cnt = 0; 
	for(int i=2; i<=n; i++){
		if(!euler[i]){
			euler[i] = i-1;
			prime[cnt++] = i;
		} 
		for(int j=0; j<cnt&&prime[j]*i<=n; j++){
			if(i%prime[j]) euler[prime[j]*i] = euler[i]*(prime[j]-1);
			else {
				euler[prime[j]*i] = euler[i]*prime[j];
				break;
			}
		}
	}
}