double convex_diameter(Point *p, int n, int &First, int &Second){
	double maxd = 0;
	if (n == 1){
		First = Second = 0;
		return maxd;
	}
	#define next(i) ((i+1)%n)
	for (int i = 0, j = 1; i < n; ++i){
		while (dbcmp(det(p[next(i)] - p[i], p[j] - p[i]) - det(p[next(i)] - p[i], p[next(j)] - p[i])) < 0){
			j = next(j);
		}
		double d = dist(p[i], p[j]);
		if (d > maxd){
			maxd = d;
			First = i; Second = j;
		}
		d = dist(p[next(i)], p[next(j)]);
		if (d > maxd){
			maxd = d;
			First = next(i);
			Second = next(j);
		}
	}
	return maxd;
}

//返回凸包的最小矩形覆盖
double min_rectangle_cover(Point *p, int n){
	if (n < 3) return 0;
	p[n] = p[0];
	double ans = 1e50;
	int l, r, o;
	o = 1;
	r = 1;
	for (int i = 0; i < n; ++i){
		//卡出距离P[i]P[i+1]最远的点
		while (dbcmp(det(p[i + 1] - p[i], p[o + 1] - p[i]) - det(p[i + 1] - p[i], p[o] - p[i])) >= 0)
			o = (o + 1) % n;
		//卡出最右边的点
		while (dbcmp(dot(p[i + 1] - p[i], p[r + 1] - p[i]) - dot(p[i + 1] - p[i], p[r] - p[i])) >= 0)
			r = (r + 1) % n;
		if (i == 0) l = r;

		while (dbcmp(dot(p[i + 1] - p[i], p[l + 1] - p[i]) - dot(p[i + 1] - p[i], p[l] - p[i])) <= 0)
			l = (l + 1) % n;
		double d = dist(p[i], p[i + 1]);
		
		double H = det(p[i + 1] - p[i], p[o] - p[i]) / d;
		double L = dot(p[i + 1] - p[i], p[r] - p[i]) / d - dot(p[i + 1] - p[i], p[l] - p[i]) / d;
		ans = min(ans, fabs(L*H));
	}
	return ans;
}