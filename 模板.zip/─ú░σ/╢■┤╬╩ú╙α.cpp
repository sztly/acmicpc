//二次剩余x^2 = a (mod p)
int solve()
{

    int q = p-1,s = 0,r,t,c,b,z,i;
    while((q & 1) == 0){
        q >>= 1;
        s++;
    }
    if(s == 1) return quick_power(a,(p+1)>>2,p);
    r = quick_power(a,(q+1)>>1,p);
    t = quick_power(a,q,p);
    while(1){
        z = 1 + rand()%(p-1);
        if(quick_power(z,(p-1)>>1,p) != 1) break;
    }
    c = quick_power(z,q,p);
    while(1){
        if(t%p == 1) break;
        for(i=1; i<=s; ++i) if(quick_power(t,1<<i,p) == 1) break;
        b = quick_power(c,1<<(s-1-i),p);
        r = r*b%p;
        c = b*b%p;
        t = c*t%p;
        s = i;
    }
    return r;
} 