struct Line{
	Point a, b;
	Line(){}
	Line(Point _a, Point _b) :a(_a), b(_b){}
};

//两点生成一条直线
Line point_make_line(const Point a, const Point b){
	return Line(a, b);
}

//点到线段的距离P---->ST
double dis_point_segment(const Point p, const Point s, const Point t){
	if (dbcmp(dot(p - s, t - s)) < 0) return (p - s).getLength();
	if (dbcmp(dot(p - t, s - t)) < 0) return (p - t).getLength();
	return fabs(det(s - p, t - p) / dist(s, t));
}

//点P在直线ST上的投影，保存在cp中
void projection_point_line(const Point p, const Point s, const Point t, Point &cp){
	double r = dot((t - s), (p - s)) / dot(t - s, t - s);
	cp = s + r*(t - s);
}

//点P是否在线段ST上
bool is_point_on_segment(const Point p, const Point s, const Point t){
	return dbcmp(det(p - s, t - s)) == 0 && dbcmp(dot(p - s, p - t)) <= 0;
}

//两条直线是否平行，重合也算作平行，重合返回-1，平行返回0，相交返回1
int parallel(Line a, Line b){
	int x = dbcmp(det(a.a - a.b, b.a - b.b));
	if (x) return 1;
	x = dbcmp(det(a.a - b.a, a.a - b.b));
	if (x == 0) return -1;
	return 0;
}

//两条直线的交点，调用前保证相交
void line_make_point(Line a, Line b, Point &res){
	double s1 = det(a.a - b.a, b.b - b.a);
	double s2 = det(a.b - b.a, b.b - b.a);
	res = (s1*a.b - s2*a.a) / (s1 - s2);
}

//两条线段的交点,返回1表示规范相交，0不相交，-1部分重合, 未考虑只有端点重合的情况
int segment_make_point(Line a, Line b, Point &res){
	int c1, c2, c3, c4;
	c1 = dbcmp(det(a.a - b.a, b.b - b.a));
	c2 = dbcmp(det(a.b - b.a, b.b - b.a));
	c3 = dbcmp(det(b.a - a.a, a.b - a.a));
	c4 = dbcmp(det(b.b - a.a, a.b - a.a));
	if (c1*c2 < 0 && c3*c4 < 0){//规范相交
		line_make_point(a, b, res);
		return 1;
	}
	int state;
	if ((state = parallel(a, b)) == -1){//部分重合
		if (is_point_on_segment(a.a, b.a, b.b) || is_point_on_segment(a.b, b.a, b.b))
			return -1;
	}
	if (state == 1){
		bool flag = 0;
		if (is_point_on_segment(a.a, b.a, b.b)) res = a.a, flag = 1;
		else if (is_point_on_segment(a.b, b.a, b.b)) res = a.b, flag = 1;
		else if (is_point_on_segment(b.a, a.a, a.b)) res = b.a, flag = 1;
		else if (is_point_on_segment(b.b, a.a, a.b)) res = b.b, flag = 1;
		if (flag) return 1;
	}
	return 0;
}

//直线平移距离len
Line move_d(Line a, const double &len){
	Point d = a.b - a.a;
	d = d / d.getLength();
	d = rotate_point(d, pi / 2);
	return Line(a.a + d*len, a.b + d*len);
}