//异或矩阵的gauss消元
int a[MAX][MAX],ans[MAX]; 
int Gauss()
{
    int i,j,k,l,r;
    for(i=0,j=0; i<n,j<n; i++,j++){
        r = i;
        for(k=i+1; k<n; k++)
            if(a[k][j] > a[r][j]) r = k;
        if(r != i){
            for(k=j; k<=n; k++)
                swap(a[i][k],a[r][k]);
        }
        if(a[i][j] == 0){
            i--;
            continue;
        }
        for(k=i+1; k<n; k++){
            if(!a[k][j]) continue;
            for(l=j; l<=n; l++){
                if(a[k][l]!=a[i][l]) a[k][l] = 1;
                else a[k][l] = 0;
            }
        }
    }
    for(int i=n-1; i>=0; i--){  
        ans[i]=a[i][n];  
        for(j=i+1; j<n; j++)  
            ans[i] ^= (a[i][j]&ans[j]);  
			//需要注意，这种求答案只适用于开关问题一类的题目 
    } 
    for(int i=0; i<n; i++){
    	printf("%d\n",ans[i]);
    }
    for(k=i; k<n; k++)
        if(a[k][n] != 0) return -1;
    if(i == n) return 1;
    return 1<<(n-i);
}
//一般意义下的GAUSS消元
void Gauss()
{
	int m;
	double pm,tmp;
	for(int i=0; i<cnt; i++){
		m = i;
		for(int j=i+1; j<cnt; j++){
			if(fabs(mat[j][i]) > fabs(mat[m][i])){
				m = j;
			}
		} 
		if(m != i){
			for(int j=i; j<=cnt; j++)
				swap(mat[i][j],mat[m][j]);
		}
		//或者这样直接求出解
		x[k] /= a[k][col];
		for (j = col + 1; j<var; j++)a[k][j] /= a[k][col];
		a[k][col] = 1;
		for (i = 0; i<equ; i++)
			if (i != k){
			x[i] -= x[k] * a[i][k];
			for (j = col + 1; j<var; j++) a[i][j] -= a[k][j] * a[i][col];
			a[i][col] = 0;
		}
		//第二种写法
		for(int j=i+1; j<cnt; j++){
			pm = mat[j][i]/mat[i][i];
			for(int k=i; k<=cnt; k++){
				tmp = mat[j][k]-pm*mat[i][k];
				mat[j][k] = tmp;
			}
		}
	}
	for(int i=0; i<maxn; i++) ans[i] = 0;
	for(int i=cnt-1; i>=0; i--){
		double t = 0;
		for(int j=i+1; j<cnt; j++){
			t += mat[i][j]*ans[j];
		}
		ans[i] = (mat[i][cnt]-t)/mat[i][i];
	}
	//
}