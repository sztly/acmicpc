//求所有因子之和，需用到上面素数筛选
long long sumall[pn+2]; 
void Get_all_sum(int n=pn){
	sumall[1] = 1;
	for(int i=2; i<=n; i++){
		int t = 1;
		for(int j=i; j%mark[i]==0; j/=mark[i]) t *= mark[i];
		if(i == t) sumall[i] = (1ll*mark[i]*i-1)/(mark[i]-1);
		else sumall[i] = sumall[t]*sumall[i/t]; 
	}
}