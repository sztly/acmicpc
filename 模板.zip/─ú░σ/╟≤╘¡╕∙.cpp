//求原根
bool g_test(int r,int p){
	for(int i=0; i<a.size(); ++i){
		if(pow_mod(r,(p-1)/a[i],p) == 1) return 0;
	}
	return 1;
}

int pri_root(int p){
	int tmp = p-1;
	a.clear();
	for(int i=2; i*i<=tmp; ++i){
		if(tmp%i == 0){
			a.push_back(i);
			while(tmp%i == 0){
				tmp /= i;
			}
		}
	}
	if(tmp > 1) a.push_back(tmp);
	int res = 1;
	while(1){
		if(g_test(res,p)) return res;
		++res;
	}
}