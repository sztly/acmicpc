//一元线性同余方程，需用上面扩展欧几里得算法 
struct One_Variable_linear{
	vector<int> ans;
	int a,b,m;
	One_Variable_linear(){ans.clear();}
	void set_value(int aa,int bb,int mm){
		a = aa;b = bb;m = mm;
	}
	bool solve(){//返回true代表有解，否则无解 
		int x,y,d;
		d = extend_gcd(a,m,x,y);
		if(b%d) return false;
		x = x*(b/d)%m;
		for(int i=1; i<=d; i++){
			y = (x+(i-1)*m/d)%m;
			if(y < 0) y += m;
			ans.push_back(y);
		}
		return true;
	}
} ; 