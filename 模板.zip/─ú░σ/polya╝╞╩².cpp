//Polya计数（邻接关系矩阵表示）
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<vector>
#include<queue>
using namespace std;

const int mod = 9973;

typedef pair<int,int> PII;

struct Matrix{
	int mat[65][65];
};

int n,m,k,res;
int raw[65][65];
vector<PII> prime;
Matrix ans,mid,rc;
int cnt[65];

void multi(Matrix& a,Matrix& b){
	for(int i=0; i<k; i++){
		for(int j=0; j<k; j++){
			rc.mat[i][j] = 0;
			for(int l=0; l<(k>>1); l++){
				rc.mat[i][j] += a.mat[i][l]*b.mat[l][j];
			}
			rc.mat[i][j] %= mod;
			for(int l=(k>>1); l<k; l++) rc.mat[i][j] += a.mat[i][l]*b.mat[l][j];
			rc.mat[i][j] %= mod;
		}
	}
	a = rc;
}

void prime_div(int num){
	int cnt;
	prime.clear();
	for(int i=2; i*i<=num; i++){
		if(num%i == 0){
			cnt = 0;
			while(num%i == 0){
				cnt++;
				num/=i;
			}
			prime.push_back(make_pair(i,cnt));
		}
	}
	if(num > 1) prime.push_back(make_pair(num,1));
}

int get_euler(int num){
	int res = num;
	for(int i=0; i<prime.size(); i++){
		if(num%prime[i].first == 0){
			res -= res/prime[i].first;
		}
	}
	return res;
}

void quick_pow(int d){
	for(int i=0; i<k; i++){
		for(int j=0; j<k; j++){
			ans.mat[i][j] = i==j ? 1 : 0;
			mid.mat[i][j] = raw[i][j];
		}
	}
	while(d){
		if(d & 0x1) multi(ans,mid);
		d >>= 1;
		multi(mid,mid);
	}
}

void dfs(int no,int val){//第no个,乘积为val 
	if(no == prime.size()){
		int e = get_euler(n/val); 
		quick_pow(val);
		int t = 0;
		for(int i=0; i<k; i++){
			t = (t + ans.mat[i][i])%mod;
		}
		res = (res + t*e)%mod;
		return ;
	}
	int t = 1;
	for(int i=0; i<=prime[no].second; i++){
		dfs(no+1,val*t);
		t *=  prime[no].first;
	}
}

int extend_gcd(int a,int b,int& x,int& y){
	int d;
	if(b == 0){
		x = 1;y = 0;
		return a;
	}
	d = extend_gcd(b,a%b,y,x);
	y -= (a/b)*x;
	return d;
} 

int main()
{
	int a,b,t;
	int x,y;
	while(scanf("%d %d %d",&n,&m,&k) == 3){
		for(int i=0; i<k; i++) scanf("%d",&cnt[i]);
		memset(raw,0,sizeof(raw));
		for(int i=0; i<m; i++){
			scanf("%d %d",&a,&b);
			raw[a-1][b-1] = cnt[b-1];
		}
		if(n == 1){
			res = 0;
			for(int i=0; i<k; i++){
				res = (res + cnt[i])%mod;
			}
			printf("%d\n",res);continue;
		}
		prime_div(n);
		res = 0;
		t = 1;
		for(int i=0; i<=prime[0].second; i++){
			dfs(1,t);
			t *= prime[0].first;
		}
		extend_gcd(n,mod,x,y);
//		printf("%d\n",x);
		res = (res * x)%mod;
		res = (res + mod)%mod;
		printf("%d\n",res);
	}
	return 0;
}