//AC自动机
const int Z = 128;
const int MN = 100002;
const int maxlen = 10002;

int ans[5],cnt,tot;

struct ACautomation{
	int chd[MN][Z],fail[MN],Q[MN],nn,mark[MN];
	bool flag[505];
	
	void init(){
		fail[0] = 0;
		memset(chd[0],0,sizeof(chd[0]));
		memset(mark,0,sizeof(mark));
		nn = 1;
	}
	
	void insert(char *a,int id){
		int p = 0;
		while(*a){
			int c = *a++;
			if(!chd[p][c]){
				memset(chd[nn],0,sizeof(chd[nn]));
				chd[p][c] = nn++;
			}
			p = chd[p][c];
		}
		mark[p] = id;
	}
	
	void build(){
		int *s = Q,*e = Q;
		for(int i=0; i<Z; i++){
			if(chd[0][i]) {
				*e++ = chd[0][i];
				fail[chd[0][i]] = 0;
			}
		}
		while(s != e){
			int u = *s++;
			for(int i=0; i<Z; i++){
				int v = chd[u][i];
				if(v){
					*e++ = v;
					int t = fail[u];
					while(t && !chd[t][i]) t = fail[t];
					fail[v] = chd[t][i];
				}
			}
		}
	}
	void solve(char *a){
		cnt = 0;
		int p = 0;
		memset(flag,0,sizeof(flag));
		for(int i=0; a[i]; i++){
			int k = a[i];
			while(chd[p][k]==0 && p!=0) 
				p = fail[p];
			if(chd[p][k]) p = chd[p][k];
			int tmp = p;
			while(tmp != 0){
				if(mark[tmp] && !flag[mark[tmp]]){
					ans[cnt++] = mark[tmp];
					flag[mark[tmp]] = 1;
				}
				tmp = fail[tmp];
			}
		}
	}
}AC; 