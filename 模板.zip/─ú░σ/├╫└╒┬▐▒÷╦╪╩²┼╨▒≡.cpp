//米勒罗宾素数测试 
int Times = 100;
bool witness(long long a,long long n){
	long long m = n-1;
	int j = 0;
	while((m&1) == 0){
		j++;m>>=1;
	}
	long long x = quick_power(a,m,n);
	if(x==1 || x==n-1) return false;
	while(j--){
		x = (x*x)%n;
		if(x == n-1) return false;
	}
	return true;
}
bool Miller_Rabin(long long n){
	srand(time(0));
	if(n < 2) return 0;
	if(n == 2) return 1;
	if((n&1) == 0) return 0;
	for(int i=0; i<Times; i++){
		long long a = random(n-2)+1;
		if(witness(a,n)) return false; 
	}
	return true;
}