//筛素数并挑选最小素数因子 
const int pn = 100;
int mark[pn+1],prime[pn+1],cnt;
void Get_Prime(int n=pn){
	memset(mark,0,sizeof(mark));
	cnt = 0;
	for(int i=2; i<=n; i++){
		if(!mark[i]) mark[i] = prime[cnt++] = i;
		for(int j=0; j<cnt&&prime[j]*i<=n; j++){
			mark[i*prime[j]] = prime[j];
			if(i%prime[j] == 0) break;
		}
	}
}