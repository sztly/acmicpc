struct Point {
	double x, y;
	Point(){}
	Point(double a, double b) :x(a), y(b){}
	void input(){
		scanf("%lf%lf", &x, &y);
	}
	friend bool operator < (const Point &a, const Point &b){
		return dbcmp(a.x - b.x) < 0 || (dbcmp(a.x - b.x) == 0 && dbcmp(a.y - b.y) < 0);
	}
	friend Point operator + (const Point &a, const Point &b){
		return Point(a.x + b.x, a.y + b.y);
	}
	friend Point operator - (const Point &a, const Point &b){
		return Point(a.x - b.x, a.y - b.y);
	}
	friend bool operator == (const Point &a, const Point &b){
		return dbcmp(a.x - b.x) == 0 && dbcmp(a.y - b.y) == 0;
	}
	friend Point operator * (const Point &a, const double &b){
		return Point(a.x*b, a.y*b);
	}
	friend Point operator * (const double &a, const Point &b){
		return Point(a*b.x, a*b.y);
	}
	friend Point operator /(const Point &a, const double &b){
		return Point(a.x / b, a.y / b);
	}
	double getLength(){
		return sqrt(x*x + y*y);
	}
};

double det(const Point &a, const Point &b){
	return a.x*b.y - a.y*b.x;
}

double dot(const Point &a, const Point &b){
	return a.x*b.x + a.y*b.y;
}

double dist(const Point &a, const Point &b){
	return (a - b).getLength();
}

//点或者向量的旋转
Point rotate_point(const Point &a, double A){
	double tx = a.x, ty = a.y;
	return Point(tx*cos(A) - ty*sin(A), tx*sin(A) + ty*cos(A));
}