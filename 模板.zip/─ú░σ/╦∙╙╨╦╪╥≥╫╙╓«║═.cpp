//求所有素因子之和，需用到上面素数筛选
int sump[pn+2];
void Get_prime_sum(int n=pn){
	sump[1] = 0;
	for(int i=2; i<=n; i++){
		int t = 1;
		for(int j=i; j%mark[i]==0; j/=mark[i]) t *= mark[i];
		sump[i] = mark[i]+sump[i/t];
	}
} 