//梅森素数-卢卡斯判别
// r(k) = r(k-1)^2 - 2 (mod M(p)), 0 < r(k) < M(p)
//M(p) = 2^p - 1;
//M(p)是素数当且仅当r(p-1) = 0 (mod M(p)) 

//扩展欧几里得算法：ax+by=d，返回最大公约数d 
int extend_gcd(int a,int b,int& x,int& y)
{ 
	int d = a;
	if(b != 0){
		d = extend_gcd(b,a%b,y,x);
		y -= (a/b)*x;
	}
	else {
		x = 1;y = 0;
	}
	return d;
}