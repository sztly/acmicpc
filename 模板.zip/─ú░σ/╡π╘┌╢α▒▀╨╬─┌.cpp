//点p是否在多边形poly中，-1表示在边界上，0---外部，1---内部
int is_point_in_polygon(Point p, Point *poly, int n){
	int w = 0;
	for (int i = 0; i < n; ++i){
		if (is_point_on_segment(p, poly[i], poly[(i + 1) % n])) return -1;
		int d1 = dbcmp(poly[i].y - p.y);
		int d2 = dbcmp(poly[(i + 1) % n].y - p.y);
		int k = dbcmp(det(poly[(i + 1) % n] - poly[i], p - poly[i]));
		if (k>0 && d1 <= 0 && d2 > 0) ++w;
		if (k < 0 && d1>0 && d2 <= 0) --w;
	}
	if (w != 0) return 1;
	return 0;
}